/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package demonstration;

/**
 *
 * @author duyb
 */
public class Vector {
    public float x,y,z;
    public float sqrMagnitude;
    public float magnitude;
    
    public Vector(){
        x=y=z=0;
    }
    
    public Vector(float x,float y,float z){
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public void SqrMagnitude(){
        sqrMagnitude = x*x + y*y + z*z;
    }
    
    public void Magnitude(){
        magnitude = (float)Math.sqrt(sqrMagnitude);
    }
}
